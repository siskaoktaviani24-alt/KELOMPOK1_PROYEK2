<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pencarian Menu - Kedai Kopi Aroma</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .hero-section {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 80px 0;
        }
        .coffee-bg {
            background-color: #8B4513;
        }
        .btn-coffee {
            background-color: #8B4513;
            color: white;
            border: none;
        }
        .btn-coffee:hover {
            background-color: #654321;
            color: white;
        }
        .search-card {
            border: none;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .menu-card {
            border: none;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            height: 100%;
        }
        .menu-card:hover {
            transform: translateY(-3px);
        }
        .price-tag {
            font-size: 1.1rem;
            font-weight: bold;
            color: #8B4513;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark coffee-bg">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="fas fa-coffee me-2"></i>
                Kedai Kopi Aroma
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="<?php echo e(route('menu.index')); ?>">
                    <i class="fas fa-utensils me-1"></i>Semua Menu
                </a>
                <a class="nav-link" href="<?php echo e(route('booking_tempat.create')); ?>">
                    <i class="fas fa-calendar-alt me-1"></i>Booking Tempat
                </a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero-section text-center">
        <div class="container">
            <h1 class="display-4 fw-bold">Cari Menu</h1>
            <p class="lead">Temukan menu favorit Anda dengan mudah</p>
        </div>
    </div>

    <!-- Search Form -->
    <div class="container my-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card search-card">
                    <div class="card-body p-4">
                        <form action="<?php echo e(route('menu.search')); ?>" method="GET">
                            <div class="input-group input-group-lg">
                                <input type="text" class="form-control" name="q" placeholder="Cari menu..." value="<?php echo e(request('q')); ?>">
                                <button class="btn btn-coffee" type="submit">
                                    <i class="fas fa-search"></i> Cari
                                </button>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-6">
                                    <select class="form-select" name="category">
                                        <option value="">Semua Kategori</option>
                                        <option value="Kopi" <?php echo e(request('category') == 'Kopi' ? 'selected' : ''); ?>>Kopi</option>
                                        <option value="Makanan" <?php echo e(request('category') == 'Makanan' ? 'selected' : ''); ?>>Makanan</option>
                                        <option value="Non-Kopi" <?php echo e(request('category') == 'Non-Kopi' ? 'selected' : ''); ?>>Non-Kopi</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <select class="form-select" name="sort">
                                        <option value="name_asc" <?php echo e(request('sort') == 'name_asc' ? 'selected' : ''); ?>>Nama A-Z</option>
                                        <option value="name_desc" <?php echo e(request('sort') == 'name_desc' ? 'selected' : ''); ?>>Nama Z-A</option>
                                        <option value="price_asc" <?php echo e(request('sort') == 'price_asc' ? 'selected' : ''); ?>>Harga Terendah</option>
                                        <option value="price_desc" <?php echo e(request('sort') == 'price_desc' ? 'selected' : ''); ?>>Harga Tertinggi</option>
                                    </select>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Search Results -->
    <div class="container my-4">
        <?php if(isset($results) && $results->count() > 0): ?>
        <div class="row mb-4">
            <div class="col-12">
                <h4>Hasil Pencarian untuk "<?php echo e(request('q')); ?>"</h4>
                <p class="text-muted">Ditemukan <?php echo e($results->count()); ?> menu</p>
            </div>
        </div>

        <div class="row">
            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <div class="card menu-card">
                    <div class="card-body">
                        <h6 class="card-title"><?php echo e($item->nama_menu); ?></h6>
                        <p class="card-text text-muted small"><?php echo e(Str::limit($item->deskripsi, 50)); ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="price-tag">Rp <?php echo e(number_format($item->harga, 0, ',', '.')); ?></span>
                            <span class="badge 
                                <?php if($item->kategori == 'Kopi'): ?> bg-coffee
                                <?php elseif($item->kategori == 'Makanan'): ?> bg-success
                                <?php else: ?> bg-info <?php endif; ?> small">
                                <?php echo e($item->kategori); ?>

                            </span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mt-2">
                            <span class="badge 
                                <?php if($item->stok > 10): ?> bg-success
                                <?php elseif($item->stok > 0): ?> bg-warning
                                <?php else: ?> bg-danger <?php endif; ?> small">
                                Stok: <?php echo e($item->stok); ?>

                            </span>
                        </div>
                        <div class="d-grid gap-1 mt-2">
                            <a href="<?php echo e(route('menu.show', $item->id)); ?>" class="btn btn-outline-coffee btn-sm">
                                <i class="fas fa-info-circle me-1"></i>Detail
                            </a>
                            <button class="btn btn-coffee btn-sm add-to-cart" 
                                    data-menu-id="<?php echo e($item->id); ?>" 
                                    data-menu-name="<?php echo e($item->nama_menu); ?>" 
                                    data-menu-price="<?php echo e($item->harga); ?>" 
                                    data-menu-stok="<?php echo e($item->stok); ?>"
                                    <?php if($item->stok == 0): ?> disabled <?php endif; ?>>
                                <i class="fas fa-cart-plus me-1"></i>
                                <?php if($item->stok == 0): ?>
                                    Stok Habis
                                <?php else: ?>
                                    Tambah ke Pesanan
                                <?php endif; ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php elseif(request()->has('q')): ?>
        <div class="text-center py-5">
            <i class="fas fa-search fa-3x text-muted mb-3"></i>
            <h4 class="text-muted">Tidak ada hasil ditemukan</h4>
            <p class="text-muted">Coba dengan kata kunci lain atau lihat <a href="<?php echo e(route('menu.index')); ?>">semua menu</a></p>
        </div>
        <?php endif; ?>
    </div>

    <!-- Cart Button -->
    <div class="position-fixed bottom-0 end-0 m-4">
        <button class="btn btn-coffee btn-lg rounded-pill shadow" data-bs-toggle="offcanvas" data-bs-target="#cartOffcanvas">
            <i class="fas fa-shopping-cart me-2"></i>
            <span class="badge bg-danger" id="cart-count">0</span>
        </button>
    </div>

    <!-- Shopping Cart Sidebar -->
    <div class="offcanvas offcanvas-end" tabindex="-1" id="cartOffcanvas">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title"><i class="fas fa-shopping-cart me-2"></i>Keranjang Pesanan</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body">
            <div id="cart-items">
                <p class="text-muted text-center">Keranjang kosong</p>
            </div>
            <div class="mt-auto">
                <div class="d-flex justify-content-between mb-3">
                    <strong>Total:</strong>
                    <strong id="cart-total">Rp 0</strong>
                </div>
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('booking_tempat.create')); ?>" class="btn btn-coffee">
                        <i class="fas fa-calendar-check me-2"></i>Booking Tempat & Pesan
                    </a>
                    <button class="btn btn-outline-secondary" data-bs-dismiss="offcanvas">
                        <i class="fas fa-times me-2"></i>Tutup
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-4 mt-5">
        <div class="container">
            <p class="mb-0">&copy; 2024 Kedai Kopi Aroma. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let cart = [];
        
        // Add to cart functionality
        document.querySelectorAll('.add-to-cart').forEach(btn => {
            btn.addEventListener('click', function() {
                if (this.disabled) return;
                
                const menuId = this.getAttribute('data-menu-id');
                const menuName = this.getAttribute('data-menu-name');
                const menuPrice = parseInt(this.getAttribute('data-menu-price'));
                const menuStok = parseInt(this.getAttribute('data-menu-stok'));
                
                // Check stok
                if (menuStok === 0) {
                    alert('Stok habis!');
                    return;
                }
                
                // Add to cart
                const existingItem = cart.find(item => item.id === menuId);
                if (existingItem) {
                    if (existingItem.quantity >= menuStok) {
                        alert('Stok tidak mencukupi!');
                        return;
                    }
                    existingItem.quantity++;
                } else {
                    cart.push({
                        id: menuId,
                        name: menuName,
                        price: menuPrice,
                        quantity: 1,
                        stok: menuStok
                    });
                }
                
                updateCart();
                
                // Show success message
                const toast = document.createElement('div');
                toast.className = 'position-fixed top-0 end-0 m-3 alert alert-success alert-dismissible fade show';
                toast.style.zIndex = '9999';
                toast.innerHTML = `
                    <i class="fas fa-check-circle me-2"></i>
                    <strong>${menuName}</strong> ditambahkan ke keranjang!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;
                document.body.appendChild(toast);
                
                // Auto remove toast after 3 seconds
                setTimeout(() => {
                    if (toast.parentNode) {
                        toast.remove();
                    }
                }, 3000);
            });
        });

        function updateCart() {
            const cartItems = document.getElementById('cart-items');
            const cartTotal = document.getElementById('cart-total');
            const cartCount = document.getElementById('cart-count');
            
            if (cart.length === 0) {
                cartItems.innerHTML = '<p class="text-muted text-center">Keranjang kosong</p>';
                cartTotal.textContent = 'Rp 0';
                cartCount.textContent = '0';
                return;
            }
            
            let total = 0;
            let itemsHTML = '';
            
            cart.forEach((item, index) => {
                const subtotal = item.price * item.quantity;
                total += subtotal;
                
                itemsHTML += `
                    <div class="card mb-2">
                        <div class="card-body py-2">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-0">${item.name}</h6>
                                    <small class="text-muted">Rp ${item.price.toLocaleString('id-ID')} x ${item.quantity}</small>
                                </div>
                                <div class="d-flex align-items-center">
                                    <span class="me-2">Rp ${subtotal.toLocaleString('id-ID')}</span>
                                    <button class="btn btn-sm btn-outline-danger remove-from-cart" data-index="${index}">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            cartItems.innerHTML = itemsHTML;
            cartTotal.textContent = 'Rp ' + total.toLocaleString('id-ID');
            cartCount.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
            
            // Add remove event listeners
            document.querySelectorAll('.remove-from-cart').forEach(btn => {
                btn.addEventListener('click', function() {
                    const index = parseInt(this.getAttribute('data-index'));
                    cart.splice(index, 1);
                    updateCart();
                });
            });
        }

        // Initialize cart from localStorage
        document.addEventListener('DOMContentLoaded', function() {
            const savedCart = localStorage.getItem('menu_cart');
            if (savedCart) {
                cart = JSON.parse(savedCart);
                updateCart();
            }
            
            // Save cart to localStorage when updated
            const originalUpdateCart = updateCart;
            updateCart = function() {
                originalUpdateCart();
                localStorage.setItem('menu_cart', JSON.stringify(cart));
            };
        });
    </script>
</body>
</html><?php /**PATH C:\laragon\www\proyek2\resources\views/menu/search.blade.php ENDPATH**/ ?>