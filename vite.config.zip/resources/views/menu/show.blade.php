<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $menu->nama_menu }} - Kedai Kopi Aroma</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .coffee-bg {
            background-color: #8B4513;
        }
        .btn-coffee {
            background-color: #8B4513;
            color: white;
            border: none;
        }
        .btn-coffee:hover {
            background-color: #654321;
            color: white;
        }
        .menu-detail-card {
            border: none;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .menu-image {
            height: 400px;
            background-size: cover;
            background-position: center;
            border-radius: 10px;
        }
        .price-tag {
            font-size: 2rem;
            font-weight: bold;
            color: #8B4513;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark coffee-bg">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="fas fa-coffee me-2"></i>
                Kedai Kopi Aroma
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="{{ route('menu.index') }}">
                    <i class="fas fa-arrow-left me-1"></i>Kembali ke Menu
                </a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="menu-image" style="background-image: url('https://images.unsplash.com/photo-1544787219-7f47ccb76574?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80');"></div>
            </div>
            <div class="col-md-6">
                <div class="card menu-detail-card">
                    <div class="card-body p-4">
                        <span class="badge 
                            @if($menu->kategori == 'Kopi') bg-coffee
                            @elseif($menu->kategori == 'Makanan') bg-success
                            @else bg-info @endif mb-3">
                            {{ $menu->kategori }}
                        </span>
                        
                        <h1 class="card-title">{{ $menu->nama_menu }}</h1>
                        <p class="card-text lead">{{ $menu->deskripsi }}</p>
                        
                        <div class="mb-4">
                            <span class="price-tag">Rp {{ number_format($menu->harga, 0, ',', '.') }}</span>
                            <span class="badge 
                                @if($menu->stok > 10) bg-success
                                @elseif($menu->stok > 0) bg-warning
                                @else bg-danger @endif ms-2">
                                Stok: {{ $menu->stok }}
                            </span>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button class="btn btn-coffee btn-lg add-to-cart-detail" 
                                    data-menu-id="{{ $menu->id }}" 
                                    data-menu-name="{{ $menu->nama_menu }}" 
                                    data-menu-price="{{ $menu->harga }}" 
                                    data-menu-stok="{{ $menu->stok }}">
                                <i class="fas fa-cart-plus me-2"></i>Tambah ke Pesanan
                            </button>
                            <a href="{{ route('menu.index') }}" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Kembali ke Daftar Menu
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-4 mt-5">
        <div class="container">
            <p class="mb-0">&copy; 2024 Kedai Kopi Aroma. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelector('.add-to-cart-detail').addEventListener('click', function() {
            const menuId = this.getAttribute('data-menu-id');
            const menuName = this.getAttribute('data-menu-name');
            const menuPrice = parseInt(this.getAttribute('data-menu-price'));
            const menuStok = parseInt(this.getAttribute('data-menu-stok'));
            
            // Simpan ke localStorage (simulasi cart)
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            
            const existingItem = cart.find(item => item.id === menuId);
            if (existingItem) {
                if (existingItem.quantity >= menuStok) {
                    alert('Stok tidak mencukupi!');
                    return;
                }
                existingItem.quantity++;
            } else {
                cart.push({
                    id: menuId,
                    name: menuName,
                    price: menuPrice,
                    quantity: 1,
                    stok: menuStok
                });
            }
            
            localStorage.setItem('cart', JSON.stringify(cart));
            alert(menuName + ' ditambahkan ke keranjang!');
        });
    </script>
</body>
</html>