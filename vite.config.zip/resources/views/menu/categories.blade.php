<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pencarian Menu - Kedai Kopi Aroma</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .hero-section {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 80px 0;
        }
        .coffee-bg {
            background-color: #8B4513;
        }
        .btn-coffee {
            background-color: #8B4513;
            color: white;
            border: none;
        }
        .btn-coffee:hover {
            background-color: #654321;
            color: white;
        }
        .search-card {
            border: none;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .menu-card {
            border: none;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            height: 100%;
        }
        .menu-card:hover {
            transform: translateY(-3px);
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark coffee-bg">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="fas fa-coffee me-2"></i>
                Kedai Kopi Aroma
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="{{ route('menu.index') }}">
                    <i class="fas fa-utensils me-1"></i>Semua Menu
                </a>
                <a class="nav-link" href="{{ route('menu.categories') }}">
                    <i class="fas fa-list me-1"></i>Kategori
                </a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero-section text-center">
        <div class="container">
            <h1 class="display-4 fw-bold">Cari Menu</h1>
            <p class="lead">Temukan menu favorit Anda dengan mudah</p>
        </div>
    </div>

    <!-- Search Form -->
    <div class="container my-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card search-card">
                    <div class="card-body p-4">
                        <form action="{{ route('menu.search') }}" method="GET">
                            <div class="input-group input-group-lg">
                                <input type="text" class="form-control" name="q" placeholder="Cari menu..." value="{{ request('q') }}">
                                <button class="btn btn-coffee" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-6">
                                    <select class="form-select" name="category">
                                        <option value="">Semua Kategori</option>
                                        <option value="Kopi" {{ request('category') == 'Kopi' ? 'selected' : '' }}>Kopi</option>
                                        <option value="Makanan" {{ request('category') == 'Makanan' ? 'selected' : '' }}>Makanan</option>
                                        <option value="Non-Kopi" {{ request('category') == 'Non-Kopi' ? 'selected' : '' }}>Non-Kopi</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <select class="form-select" name="sort">
                                        <option value="name_asc" {{ request('sort') == 'name_asc' ? 'selected' : '' }}>Nama A-Z</option>
                                        <option value="name_desc" {{ request('sort') == 'name_desc' ? 'selected' : '' }}>Nama Z-A</option>
                                        <option value="price_asc" {{ request('sort') == 'price_asc' ? 'selected' : '' }}>Harga Terendah</option>
                                        <option value="price_desc" {{ request('sort') == 'price_desc' ? 'selected' : '' }}>Harga Tertinggi</option>
                                    </select>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Search Results -->
    <div class="container my-4">
        @if(isset($results) && $results->count() > 0)
        <div class="row mb-4">
            <div class="col-12">
                <h4>Hasil Pencarian untuk "{{ request('q') }}"</h4>
                <p class="text-muted">Ditemukan {{ $results->count() }} menu</p>
            </div>
        </div>

        <div class="row">
            @foreach($results as $item)
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <div class="card menu-card">
                    <div class="card-body">
                        <h6 class="card-title">{{ $item->nama_menu }}</h6>
                        <p class="card-text text-muted small">{{ Str::limit($item->deskripsi, 50) }}</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-coffee fw-bold">Rp {{ number_format($item->harga, 0, ',', '.') }}</span>
                            <span class="badge bg-secondary small">{{ $item->kategori }}</span>
                        </div>
                        <div class="d-grid gap-1 mt-2">
                            <a href="{{ route('menu.show', $item->id) }}" class="btn btn-outline-coffee btn-sm">
                                Detail
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
        @elseif(request()->has('q'))
        <div class="text-center py-5">
            <i class="fas fa-search fa-3x text-muted mb-3"></i>
            <h4 class="text-muted">Tidak ada hasil ditemukan</h4>
            <p class="text-muted">Coba dengan kata kunci lain atau lihat <a href="{{ route('menu.index') }}">semua menu</a></p>
        </div>
        @endif
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-4 mt-5">
        <div class="container">
            <p class="mb-0">&copy; 2024 Kedai Kopi Aroma. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>