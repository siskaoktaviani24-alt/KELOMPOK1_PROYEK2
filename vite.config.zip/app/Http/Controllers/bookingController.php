<?php

namespace App\Http\Controllers;

use App\Models\booking;
use App\Models\menu;
use App\Models\bookingTempat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class bookingController extends Controller
{
    public function index()
    {
        $booking = booking::all();
        return view('booking.index', compact('booking'));
    }

public function create()
{
    $menu = Menu::where('stok', '>', 0)->get();
    
    // Cek apakah ada session booking aktif
    $isFromBookingSession = false;
    $bookingData = [];
    
    if (session()->has('booking_data')) {
        $isFromBookingSession = true;
        $bookingData = session('booking_data');
    }
    
    return view('booking.create', compact('menu', 'isFromBookingSession', 'bookingData'));
}

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_pelanggan' => 'required|string|max:255',
            'nomor_meja' => 'required|string|max:10|unique:booking,nomor_meja',
            'pesanan' => 'required|array|min:1',
            'pesanan.*.menu_id' => 'required|exists:menu,id',
            'pesanan.*.jumlah' => 'required|integer|min:1',
            'metode_bayar' => 'required|in:cash,dana'
        ]);

        DB::beginTransaction();
        
        try {
            // Check if this is from booking tempat session
            $isFromBookingTempat = session()->has('current_booking_id');
            
            if ($isFromBookingTempat) {
                $bookingTempat = bookingTempat::find(session('current_booking_id'));
                if ($bookingTempat) {
                    $validated['nama_pelanggan'] = $bookingTempat->nama_pelanggan;
                    $validated['nomor_meja'] = $bookingTempat->kode_booking;
                }
                // Clear session after use
                session()->forget('current_booking_id');
                session()->forget('current_booking_data');
            }

            // Clear cart session if exists
            session()->forget('cart_data');

            // Hitung total harga dan update stok
            $totalHarga = 0;
            $pesananDetails = [];

            foreach ($validated['pesanan'] as $item) {
                $menuItem = menu::find($item['menu_id']);
                
                if ($menuItem->stok < $item['jumlah']) {
                    throw new \Exception('Stok ' . $menuItem->nama_menu . ' tidak mencukupi. Stok tersedia: ' . $menuItem->stok);
                }

                $subtotal = $menuItem->harga * $item['jumlah'];
                $totalHarga += $subtotal;

                // Kurangi stok
                $menuItem->decrement('stok', $item['jumlah']);

                $pesananDetails[] = [
                    'menu_id' => $menuItem->id,
                    'nama_menu' => $menuItem->nama_menu,
                    'harga' => $menuItem->harga,
                    'jumlah' => $item['jumlah'],
                    'subtotal' => $subtotal
                ];
            }

            $booking = booking::create([
                'nama_pelanggan' => $validated['nama_pelanggan'],
                'nomor_meja' => $validated['nomor_meja'],
                'pesanan' => $pesananDetails,
                'total_harga' => $totalHarga,
                'metode_bayar' => $validated['metode_bayar'],
                'status' => $validated['metode_bayar'] === 'dana' ? 'diproses' : 'pending'
            ]);

            DB::commit();

            $message = $isFromBookingTempat 
                ? 'Pesanan menu berhasil ditambahkan ke booking tempat Anda! Total: Rp ' . number_format($totalHarga, 0, ',', '.')
                : 'Booking berhasil dibuat! Total: Rp ' . number_format($totalHarga, 0, ',', '.');

            if ($validated['metode_bayar'] === 'dana') {
                $message .= ' (Pembayaran DANA berhasil diproses)';
            }

            return redirect()->route('booking.index')
                ->with('success', $message);

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withErrors(['error' => $e->getMessage()])->withInput();
        }
    }

    // TAMBAH METHOD BARU UNTUK CART
    public function addToCart(Request $request)
    {
        $request->validate([
            'menu_id' => 'required|exists:menu,id',
            'quantity' => 'required|integer|min:1'
        ]);

        $menu = menu::findOrFail($request->menu_id);
        
        if ($menu->stok < $request->quantity) {
            return response()->json([
                'success' => false,
                'message' => 'Stok tidak mencukupi. Stok tersedia: ' . $menu->stok
            ]);
        }

        $cart = session()->get('cart_data', []);
        
        // Check if item already in cart
        $existingIndex = collect($cart)->search(function ($item) use ($request) {
            return $item['menu_id'] == $request->menu_id;
        });

        if ($existingIndex !== false) {
            // Update quantity
            $cart[$existingIndex]['quantity'] += $request->quantity;
        } else {
            // Add new item
            $cart[] = [
                'menu_id' => $menu->id,
                'nama_menu' => $menu->nama_menu,
                'harga' => $menu->harga,
                'quantity' => $request->quantity,
                'subtotal' => $menu->harga * $request->quantity
            ];
        }

        session()->put('cart_data', $cart);
        
        return response()->json([
            'success' => true,
            'message' => 'Item berhasil ditambahkan ke keranjang',
            'cart_count' => count($cart),
            'cart_total' => $this->calculateCartTotal($cart)
        ]);
    }

    public function removeFromCart(Request $request)
    {
        $cart = session()->get('cart_data', []);
        
        $cart = array_filter($cart, function ($item) use ($request) {
            return $item['menu_id'] != $request->menu_id;
        });

        session()->put('cart_data', array_values($cart));
        
        return response()->json([
            'success' => true,
            'message' => 'Item berhasil dihapus dari keranjang',
            'cart_count' => count($cart),
            'cart_total' => $this->calculateCartTotal($cart)
        ]);
    }

    public function getCart()
    {
        $cart = session()->get('cart_data', []);
        
        return response()->json([
            'cart_items' => $cart,
            'cart_count' => count($cart),
            'cart_total' => $this->calculateCartTotal($cart)
        ]);
    }

    public function clearCart()
    {
        session()->forget('cart_data');
        
        return response()->json([
            'success' => true,
            'message' => 'Keranjang berhasil dikosongkan'
        ]);
    }

    private function calculateCartTotal($cart)
    {
        return array_reduce($cart, function ($total, $item) {
            return $total + ($item['harga'] * $item['quantity']);
        }, 0);
    }

    // TAMBAH METHOD UNTUK PROSES PEMBAYARAN DANA
    public function processDanaPayment(Request $request)
    {
        // Simulasi proses pembayaran DANA
        // Di implementasi real, ini akan integrate dengan API DANA
        
        sleep(2); // Simulasi proses
        
        return response()->json([
            'success' => true,
            'message' => 'Pembayaran DANA berhasil diproses',
            'transaction_id' => 'DANA_' . time() . '_' . rand(1000, 9999)
        ]);
    }
}