<?php

namespace App\Http\Controllers;

use App\Models\menu;
use Illuminate\Http\Request;

class menuController extends Controller
{
    public function index(Request $request)
    {
        $query = menu::where('stok', '>', 0);
        
        // Filter by category
        if ($request->has('category') && $request->category != 'all') {
            $query->where('kategori', $request->category);
        }
        
        $menu = $query->get();
        
        // Check if user has active booking session
        $bookingData = session('current_booking_data');
        $hasBookingSession = !empty($bookingData);
        
        return view('menu.menu', compact('menu', 'hasBookingSession', 'bookingData'));
    }

    public function show($id)
    {
        $menu = menu::findOrFail($id);
        return view('menu.show', compact('menu'));
    }

    public function categories()
    {
        $menu = menu::where('stok', '>', 0)->get();
        return view('menu.categories', compact('menu'));
    }

    public function search(Request $request)
    {
        $query = menu::where('stok', '>', 0);
        
        // Search by name
        if ($request->has('q') && !empty($request->q)) {
            $query->where('nama_menu', 'like', '%' . $request->q . '%')
                  ->orWhere('deskripsi', 'like', '%' . $request->q . '%');
        }
        
        // Filter by category
        if ($request->has('category') && !empty($request->category)) {
            $query->where('kategori', $request->category);
        }
        
        // Sort results
        if ($request->has('sort')) {
            switch ($request->sort) {
                case 'name_asc':
                    $query->orderBy('nama_menu', 'asc');
                    break;
                case 'name_desc':
                    $query->orderBy('nama_menu', 'desc');
                    break;
                case 'price_asc':
                    $query->orderBy('harga', 'asc');
                    break;
                case 'price_desc':
                    $query->orderBy('harga', 'desc');
                    break;
                default:
                    $query->orderBy('nama_menu', 'asc');
            }
        } else {
            $query->orderBy('nama_menu', 'asc');
        }
        
        $results = $query->get();
        
        return view('menu.search', compact('results'));
    }
}