<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class booking extends Model
{
    protected $table = 'booking';
    
    protected $fillable = [
        'nama_pelanggan',
        'nomor_meja',
        'pesanan',
        'total_harga',
        'metode_bayar',
        'status'
    ];

    protected $casts = [
        'pesanan' => 'array'
    ];
}