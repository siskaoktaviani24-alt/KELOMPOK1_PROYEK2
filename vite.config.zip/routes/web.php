<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\bookingController;
use App\Http\Controllers\bookingTempatController;
use App\Http\Controllers\menuController;

Route::get('/', function () {
    return view('welcome');
});

// Routes untuk Booking (pesanan menu)
Route::resource('booking', bookingController::class);

// Routes untuk Booking Tempat (reservasi meja)
Route::prefix('booking-tempat')->name('booking_tempat.')->group(function () {
    Route::get('/', [bookingTempatController::class, 'index'])->name('index'); // Pastikan ini ada
    Route::get('/create', [bookingTempatController::class, 'create'])->name('create');
    Route::post('/store', [bookingTempatController::class, 'store'])->name('store');
    Route::get('/success/{id}', [bookingTempatController::class, 'success'])->name('success');
    Route::get('/payment/{id}', [bookingTempatController::class, 'processPayment'])->name('payment');
    Route::get('/menu/{id}', [bookingTempatController::class, 'toMenu'])->name('menu');
    Route::put('/{id}/status', [bookingTempatController::class, 'updateStatus'])->name('updateStatus');
});
// Routes untuk Menu
Route::prefix('menu')->name('menu.')->group(function () {
    Route::get('/', [menuController::class, 'index'])->name('index');
    Route::get('/{id}', [menuController::class, 'show'])->name('show');
    Route::get('/kategori/semua', [menuController::class, 'categories'])->name('categories');
    Route::get('/cari/search', [menuController::class, 'search'])->name('search');
});

// Routes untuk cart dan pembayaran DANA
Route::post('/booking/add-to-cart', [bookingController::class, 'addToCart'])->name('booking.addToCart');
Route::post('/booking/remove-from-cart', [bookingController::class, 'removeFromCart'])->name('booking.removeFromCart');
Route::get('/booking/get-cart', [bookingController::class, 'getCart'])->name('booking.getCart');
Route::post('/booking/clear-cart', [bookingController::class, 'clearCart'])->name('booking.clearCart');
Route::post('/booking/process-dana', [bookingController::class, 'processDanaPayment'])->name('booking.processDana');