<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class meja extends Model
{
    protected $table = 'meja';
    
    protected $fillable = [
        'no_meja',
        'kapasitas',
        'status',
        'pesanan'
    ];

    protected $casts = [
        'pesanan' => 'array'
    ];

    // Accessor untuk nomor meja yang konsisten
    public function getNomorMejaAttribute()
    {
        return $this->no_meja;
    }
}